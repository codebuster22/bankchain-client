import React from "react";

const SearchField = ({handleChange}) => (
    <div className={"pa2"}>
        <input className={"search "} type={"search"} name={'searchField'} placeholder={"Search NPA"} onChange={handleChange}/>
    </div>
);

export default SearchField;