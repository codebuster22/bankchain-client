import React from 'react';
import NavigationBar from "./NavigationBar";
import Title from "./Title";

const Header = ({name}) => (
    <div className={"header"}>
        <Title name={name}/>
        <NavigationBar/>
    </div>
);

export default Header;