import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AuctionResult from "./Containers/AuctionResult/AuctionResult";
import Cover from "./Containers/Cover/Cover";

class App extends Component {

    constructor(props) {
        super(props);
        this.state={
            isLoaded: false,
            npa:[],
            searchField: '',
            contracts: []
        }
    }

    componentDidMount = async () => {
        try {

            this.fetchAddress().then(res=>this.feed())

            this.setState({isLoaded: true});
        } catch (error) {
            // Catch any errors for any of the above operations.
            alert(
                `Failed to load`,
            );
            console.error(error);
        }
    };

    feed =  () => {
        this.state.contracts.forEach(async element=>{
            const array = this.state.npa;
            await this.feedDataToState(element.address).then(res=>{
                if(res.flag){
                    array.push(res.Data);
                }else{
                    alert(res.Data)
                }
            })
            this.setState({npa:array});
            // console.log(this.state.npa);
        })
    }

    feedDataToState = async (_address) => {
        const response = await fetch("http://localhost:3001/fetchData",{
            method: 'post',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                address: _address
            })
        });
        return await response.json()
    }

    fetchAddress = async () =>{
        const response = await fetch('http://localhost:3001/getAddress');
        const data = await response.json();
        this.setState({
            contracts: data
        });
        // console.log(this.state.contracts);
    }

    handleOnChange = (event) =>{
        console.log(event.target.name)
        const name = event.target.name;
        const value = event.type === 'checkbox'? event.target.checked : event.target.value;
        this.setState({[name]: value});
        console.log(this.state);
    }

    filterNpa = () =>{
        if(this.state.npa.length!==0){
            console.log(this.state.npa,"NPA");
            const filter = this.state.npa.filter(each=>{
                return Object.values(each).toString().toLowerCase().includes(this.state.searchField.toLowerCase());
            })
            console.log(filter,"Filter");
        }

    }

  render() {
        this.filterNpa();
    if(this.state.isLoaded){
        return (
          <div className="App ">
              <Cover handleChange={this.handleOnChange}/>
              <AuctionResult npa={this.state.npa}/>
          </div>
      )}else{
          return <div>Loading </div>;
      }
  }
}

export default App;